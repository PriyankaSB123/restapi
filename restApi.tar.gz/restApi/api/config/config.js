const SECRET_KEY = 'asterix-needs-permit-a-38';
module.exports = { SECRET_KEY };